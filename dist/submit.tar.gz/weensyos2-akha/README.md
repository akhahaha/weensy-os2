Weensy OS 2
===============
	UCLA CS 111 Minilab 2
	Professor Peter Reiher
	Winter 2014

	Alan Kha        904030522	akhahaha@gmail.com
-------------------------------------------------------------------------------
Summary
---------------
The WeensyOS problem sets are a series of little coding exercises that are also 
complete operating systems. WeensyOS 2 deals with scheduling and 
synchronization.

Features
---------------


Installation
---------------
1. Download **weensyos2** to the CS 111 Ubuntu distro.
2. Unpack using *tar xzf weensyos2.tar.gz*.
3. Run with *make run*.
